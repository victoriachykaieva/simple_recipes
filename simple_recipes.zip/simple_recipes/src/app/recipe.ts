export interface Recipe {
    title: string;
    description: string;
    photoUrl: string;
}
